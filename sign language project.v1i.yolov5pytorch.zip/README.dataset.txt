# sign language project > 2024-03-08 10:59pm
https://universe.roboflow.com/objectdetectionworkspace-urooa/sign-language-project-opdbe

Provided by a Roboflow user
License: CC BY 4.0

